#!/bin/bash

cd /user_data/code/topk

hadoop fs -rm -r -f /output/topk

hadoop jar  $STREAM_JAR      \
 -files topk_map.py,topk_reduce.py      \
 -mapper topk_map.py      \
 -reducer topk_reduce.py      \
 -input /bigdata/gutenberg      \
 -output /output/topk

hadoop fs -text /output/topk/part* | more
