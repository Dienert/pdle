#!/usr/bin/env python3
import sys

# toma linhas da entrada padrao
for line in sys.stdin:
    
    # divide linha em palavras
    words = line.split()
    
    for word in words:
        # escreve resultado na saida padrao
        # que sera entrada para a fase reduce
        # delimitador: tab

        # exclui caracteres nao alfabeticos
        flt = ''.join(filter(str.isalpha, word))
        if flt != '':
            print ('%s\t%s' % (flt.lower(), 1))
