#!/usr/bin/env python3
import sys

# toma linhas da entrada padrao
for line in sys.stdin:
    # remove espacos em branco
    line = line.strip()
    # divide linha em palavras
    words = line.split()
    
    for word in words:
        # escreve resultado na saida padrao
        # que sera entrada para a fase reduce
        # delimitador: tab
        print ('%s\t%s' % (word, 1))