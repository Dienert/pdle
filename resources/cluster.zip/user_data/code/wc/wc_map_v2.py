#!/usr/bin/env python3
import sys

for line in sys.stdin:
    # divide a entrada em linhas
    words = line.split()
    
    for word in words:
        # escreve na saida padrao
        # a entrada para a fase reduce
        # delimitador: \t
        flt = ''.join(filter(str.isalpha, word))
        if flt != '':
            print ('%s\t%s' % (flt, 1))
