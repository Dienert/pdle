#!/usr/bin/env python3
# -*- coding: latin-1 -*-
import sys
import os
import string

irrelevantes = ['a', 'à', 'agora', 'ainda', 'alguém', 'algum', 'alguma', 'algumas', 'alguns', 'ampla', 'amplas', 'amplo', 'amplos', 'ante', 'antes', 'ao', 'aos', 'após', 'aquela', 'aquelas', 'aquele', 'aqueles', 'aquilo', 'as', 'até', 'cada', 'com', 'como', 'contra', 'contudo', 'da', 'daquele', 'daqueles', 'das', 'de', 'deve', 'do', 'dos', 'e', 'é', 'e', 'ela', 'elas', 'ele', 'eles', 'em', 'enquanto', 'entre', 'era', 'essa', 'essas', 'esse', 'esses', 'esta', 'está', 'estas', 'este', 'estes', 'for', 'há', 'isso', 'isto', 'já', 'la', 'lá', 'lhe', 'lhes', 'lo', 'mas', 'me', 'na', 'não', 'nas', 'nem', 'nessa', 'nessas', 'nesta', 'nestas', 'no', 'nos', 'nós', 'nossa', 'nossas', 'nosso', 'nossos', 'num', 'numa', 'nunca', 'o', 'os', 'ou', 'para', 'pela', 'pelas', 'pelo', 'pelos', 'per', 'perante', 'pois', 'por', 'porém', 'quais', 'qual', 'quando', 'quanto', 'quantos', 'que', 'quem', 'são', 'se', 'seja', 'sejam', 'sem', 'sendo', 'será', 'serão', 'seu', 'seus', 'si', 'sido', 'só', 'sob', 'sobre', 'sua', 'suas', 'talvez', 'também', 'tampouco', 'te', 'tem', 'tendo', 'tenha', 'ter', 'teu', 'teus', 'ti', 'toda', 'todas', 'todavia', 'todo', 'todos', 'tu', 'tua', 'tuas', 'um', 'uma', 'umas', 'uns', 'vendo', 'ver', 'vez', 'vindo', 'vir', 'vos', 'vós']

def relevante(word):
    if word in irrelevantes or word == "":
        return False
    else:
        return True

def ntdocmapper():
    for line in sys.stdin:
        words = line.strip().split()
        for word in words:
            word_f = ''.join(filter(str.isalpha, word))
            if relevante(word_f) and len(word_f) >=3:
                print ("%s\t1" % (os.getenv('mapreduce_map_input_file','???')))
          
if __name__ == '__main__':
    ntdocmapper()