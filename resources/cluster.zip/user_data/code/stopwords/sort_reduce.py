#!/usr/bin/env python3
import sys

for line in sys.stdin:
	line = line.strip()
	termo,tfidf,doc_id = line.split("\t")
	print ('%s\t\t%s\t%s' % (termo,tfidf,doc_id))
	