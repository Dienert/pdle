#!/usr/bin/env python3
# -*- coding: latin-1 -*-
import sys
import os
import string

def ntdocmapper():
  for line in sys.stdin:
    words = line.strip().split()
    for word in words:
      word_f = ''.join(filter(str.isalpha, word))
      if len(word_f) >=1:
        print ("%s\t1" % (os.getenv('mapreduce_map_input_file','???')))
          
if __name__ == '__main__':
  ntdocmapper()
