#!/usr/bin/env python3
# -*- coding: latin-1 -*-

import sys
import os

def dfmapper():
  for line in sys.stdin:
    print ("%s\t1" % line.strip())

if __name__ == '__main__':
  dfmapper()
