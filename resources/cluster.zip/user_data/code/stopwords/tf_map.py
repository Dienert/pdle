#!/usr/bin/env python3
# -*- coding: latin-1 -*-
import sys
import os
import string

def tfmapper():
  for line in sys.stdin:
    words = line.strip().split()
    for word in words:
      word_f = ''.join(filter(str.isalpha, word))
      if len(word_f) >=1:
        print ("%s\t%s\t1" % (word_f.lower(),os.getenv('mapreduce_map_input_file','noname')))

if __name__ == '__main__':
  tfmapper()
