# job MapReduce / Word Count e Top K
# Prof. Jairson Rodrigues

------------------------- job wc_v1_map / reduce -----------------------------

cd /user_data/code/wc

hadoop fs -rm -r -f /output/wc1

hadoop jar $STREAM_JAR      \
 -files wc_map_v1.py,wc_reduce.py      \
 -mapper wc_map_v1.py      \
 -reducer wc_reduce.py      \
 -input /bigdata/gutenberg      \
 -output /output/wc1

hadoop fs -text /output/wc1/part* | more


------------------------- job wc_v2_map / reduce -----------------------------

cd /user_data/code/wc

hadoop fs -rm -r -f /output/wc2

hadoop jar  $STREAM_JAR       \
 -files wc_map_v2.py,wc_reduce.py      \
 -mapper wc_map_v2.py      \
 -reducer wc_reduce.py      \
 -input /bigdata/gutenberg      \
 -output /output/wc2

hadoop fs -text /output/wc2/part* | more


------------------------- job wc_v3_map / reduce -----------------------------

cd /user_data/code/wc

hadoop fs -rm -r -f /output/wc3

hadoop jar  $STREAM_JAR       \
 -files wc_map_v3.py,wc_reduce.py   \
 -mapper wc_map_v3.py      \
 -reducer wc_reduce.py      \
 -input /bigdata/gutenberg      \
 -output output/wc3

hadoop fs -text /output/wc3/part* | more


------------------------- job wc_v4_map / reduce -----------------------------

cd /user_data/code/wc

hadoop fs -rm -r -f /output/wc4

hadoop jar  $STREAM_JAR      \
 -files wc_map_v4.py,wc_reduce.py      \
 -mapper wc_map_v4.py      \
 -reducer wc_reduce.py      \
 -input /bigdata/gutenberg      \
 -output /output/wc4

hadoop fs -text /output/wc4/part* | more

------------------------- job topk map / reduce -----------------------------

cd /user_data/code/topk

hadoop fs -rm -r -f /output/topk

hadoop jar  $STREAM_JAR      \
 -files topk_map.py,topk_reduce.py      \
 -mapper topk_map.py      \
 -reducer topk_reduce.py      \
 -input /bigdata/gutenberg      \
 -output /output/topk

hadoop fs -text /output/topk/part* | more
