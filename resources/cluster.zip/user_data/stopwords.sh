#!/bin/bash

cd /user_data/code/stopwords

hadoop fs -rm -r -f /output/stopwords/

hadoop jar $STREAM_JAR      \
	 -file tf_map.py      \
	 -file tf_reduce.py      \
	 -mapper tf_map.py      \
	 -reducer tf_reduce.py      \
	 -input /bigdata/noticias/      \
	 -output /output/stopwords/tf

hadoop jar $STREAM_JAR \
     -file df_map.py \
     -file df_reduce.py \
     -mapper df_map.py \
     -reducer df_reduce.py \
     -input /output/stopwords/tf \
     -output /output/stopwords/df


hadoop jar $STREAM_JAR \
     -file ntdoc_map.py \
     -file ntdoc_reduce.py \
     -mapper ntdoc_map.py \
     -reducer ntdoc_reduce.py \
     -input /bigdata/noticias/ \
     -output /output/stopwords/ntdoc


hadoop jar $STREAM_JAR \
     -file tfidf_map.py \
     -file tfidf_reduce.py \
     -mapper tfidf_map.py \
     -reducer tfidf_reduce.py \
     -input /output/stopwords/df \
     -input /output/stopwords/ntdoc \
     -output /output/stopwords/unsorted 

hadoop jar $STREAM_JAR \
     -file stopwords_map.py \
     -file stopwords_reduce.py \
     -mapper stopwords_map.py \
     -reducer stopwords_reduce.py \
     -input /output/stopwords/unsorted \
     -output /output/stopwords/sorted 


 cd /user_data/

hadoop fs -text /output/stopwords/sorted/part* 
